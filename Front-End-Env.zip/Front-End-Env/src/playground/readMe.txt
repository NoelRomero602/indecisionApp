live-server public --port=8090

babel src/app.js --out-file=public/scripts/app.js --presets=env,react --watch