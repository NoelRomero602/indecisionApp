var nameVar = 'Andrew';
var nameVar = 'Mike';
console.log('nameVar', nameVar);

let nameLet = "kim";
 nameLet = 'same';
console.log('nameLet:', nameLet);


const nameConst = 'frank';


console.log('namConst', nameConst);


function getPetName() {
    var petName = 'Hal';
    return petName;
}

const petName = getPetName();
console.log(petName);
 let firstName;
var fullName = 'Andre Mead';

if(fullName){
     firstName = fullName.split(' ') [0];

    console.log(firstName);

}

console.log(firstName);