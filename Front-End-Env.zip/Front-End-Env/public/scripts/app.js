'use strict';

var _validator = require('validator');

var _validator2 = _interopRequireDefault(_validator);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

console.log(_validator2.default.isEmail('nromersdao20177@gmail.com'));

// import subtract, {square, add} from './utils.js';

// console.log('app.js is running'); 
// console.log(square(5));
// console.log(add(3,2));
// console.log(subtract(5,1)); 


// import lol ,{isAdult, canDrink} from './person' 

// console.log(isAdult(27));
// console.log(canDrink(22)); 
// console.log(lol(64))
